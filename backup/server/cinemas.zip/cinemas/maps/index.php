<?php


echo "<img width='610' src='https://maps.googleapis.com/maps/api/staticmap?center=23%20PASKAL%20SHOPPING%20CENTER%20CGV&zoom=15&size=600x400&markers=icon:https://mrhrtz.com/gararetech/cinemas/CinemaMarker-48.png|-6.915289878845215,107.5942611694336&key=AIzaSyDaKRWCyxkScPm8mYRf4aFYsgpW2ljnml8'>";

?>